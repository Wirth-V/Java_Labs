package ExceptionsOfBinaryTree;

public class NotFoundElementOfTreeException extends NullPointerException{
    public NotFoundElementOfTreeException(String s) {
        super(s);
    }
}
